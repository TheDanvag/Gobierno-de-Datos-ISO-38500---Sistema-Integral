import React, { useState } from 'react';

const PolicyTable = () => {
  const [policies, setPolicies] = useState([
    { id: 1, name: 'Política de Acceso', status: 'Activa', lastReview: '2023-05-15' },
    { id: 2, name: 'Política de Privacidad', status: 'En revisión', lastReview: '2023-03-20' },
    { id: 3, name: 'Política de Retención', status: 'Activa', lastReview: '2023-06-10' },
  ]);

  return (
    <div className="rounded-md border">
      <div className="relative w-full overflow-auto">
        <table className="w-full caption-bottom text-sm">
          <thead className="[&_tr]:border-b">
            <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
              <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground w-[100px]">ID</th>
              <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Nombre</th>
              <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Estado</th>
              <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">Última Revisión</th>
              <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="[&_tr:last-child]:border-0">
            {policies.map((policy) => (
              <tr key={policy.id} className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                <td className="p-4 align-middle">{policy.id}</td>
                <td className="p-4 align-middle font-medium">{policy.name}</td>
                <td className="p-4 align-middle">
                  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                    policy.status === 'Activa' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {policy.status}
                  </span>
                </td>
                <td className="p-4 align-middle">{policy.lastReview}</td>
                <td className="p-4 align-middle text-right">
                  <button className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background hover:bg-accent hover:text-accent-foreground h-10 py-2 px-4">
                    Editar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PolicyTable;