import React from 'react';

const DashboardCard = ({ title, value, change, icon }) => {
  return (
    <div className="rounded-xl border bg-card text-card-foreground shadow">
      <div className="p-6 flex flex-row items-center justify-between space-y-0 pb-2">
        <h3 className="text-sm font-medium tracking-tight">{title}</h3>
        {icon}
      </div>
      <div className="p-6 pt-0">
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground mt-1">
          {change > 0 ? '↑' : '↓'} {Math.abs(change)}% vs último mes
        </p>
      </div>
    </div>
  );
};

export default DashboardCard;