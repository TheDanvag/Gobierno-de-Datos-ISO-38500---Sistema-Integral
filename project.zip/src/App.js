import React from 'react';
import LayoutHeader from './components/Layout/LayoutHeader';
import DashboardCard from './components/Dashboard/DashboardCard';
import PolicyTable from './components/Policies/PolicyTable';
import FileIcon from './components/Icons/FileIcon';
import UsersIcon from './components/Icons/UsersIcon';
import CheckCircleIcon from './components/Icons/CheckCircleIcon';
import DatabaseIcon from './components/Icons/DatabaseIcon';

const App = () => {
  return (
    <div className="min-h-screen bg-background">
      <LayoutHeader />
      
      <main className="container py-8">
        <h1 className="text-3xl font-bold mb-6">Panel de Gobierno de Datos</h1>
        
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <DashboardCard 
            title="Políticas Activas" 
            value="24" 
            change={5.2} 
            icon={<FileIcon className="h-4 w-4 text-muted-foreground" />}
          />
          <DashboardCard 
            title="Roles Definidos" 
            value="12" 
            change={2.8} 
            icon={<UsersIcon className="h-4 w-4 text-muted-foreground" />}
          />
          <DashboardCard 
            title="Decisiones Pendientes" 
            value="5" 
            change={-1.3} 
            icon={<CheckCircleIcon className="h-4 w-4 text-muted-foreground" />}
          />
          <DashboardCard 
            title="Activos de Datos" 
            value="143" 
            change={8.7} 
            icon={<DatabaseIcon className="h-4 w-4 text-muted-foreground" />}
          />
        </div>
        
        <div className="space-y-4">
          <h2 className="text-xl font-semibold">Políticas de Gobierno</h2>
          <PolicyTable />
        </div>
      </main>
    </div>
  );
};

export default App;

// DONE